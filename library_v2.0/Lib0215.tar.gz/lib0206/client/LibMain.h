#ifndef _LIB_MAIN_
#define _LIB_MAIN_

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/select.h>

// #define DEBUG_PRINT

/* 응답메시지 */
#define FAILURE (0)
#define SUCCESS (1)

#endif /* _LIB_MAIN_ */